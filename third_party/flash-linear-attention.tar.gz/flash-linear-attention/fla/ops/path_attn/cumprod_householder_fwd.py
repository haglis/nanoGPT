# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

import torch
import triton
import triton.language as tl

from fla.ops.utils import prepare_chunk_indices, prepare_chunk_offsets
from fla.utils import check_shared_mem


@triton.heuristics({
    'IS_VARLEN': lambda args: args['cu_seqlens'] is not None,
})
@triton.jit
def chunk_cumprod_householder_fwd_kernel(
    k,
    k_new,
    w1,
    w2,
    hc_suffix,
    hc_whole,
    cu_seqlens,
    split_indices,
    chunk_offsets,
    split_offsets,
    BT: tl.constexpr,  # small chunk size
    K: tl.constexpr,
    H: tl.constexpr,
    BK: tl.constexpr,
    T: tl.constexpr,
    S: tl.constexpr,  # split size, aka large chunk size
    IS_VARLEN: tl.constexpr,
):
    i_ss, i_h = tl.program_id(0), tl.program_id(1)

    if IS_VARLEN:
        i_n, i_s = tl.load(split_indices + i_ss * 2).to(tl.int32), tl.load(split_indices + i_ss * 2 + 1).to(tl.int32)
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int64), tl.load(cu_seqlens + i_n + 1).to(tl.int64)
        T = (eos - bos).to(tl.int32)
        NS = tl.cdiv(T, S)

        boh = tl.load(chunk_offsets + i_n).to(tl.int64)
        boh_large = tl.load(split_offsets + i_n).to(tl.int64)
    else:
        NS = tl.cdiv(T, S)
        i_n, i_s = i_ss // NS, i_ss % NS
        bos, eos = (i_n * T).to(tl.int64), (i_n * T + T).to(tl.int64)

        boh = (i_n * tl.cdiv(T, BT)).to(tl.int64)
        boh_large = (i_n * tl.cdiv(T, S)).to(tl.int64)

    NT_small = tl.cdiv(min(S, T-i_s*S), BT)
    stride_h = H*K*K

    # offset calculations
    hc_whole += ((boh_large + i_s) * H + i_h) * K * K
    hc_suffix += ((boh + tl.cdiv(i_s * S, BT)) * H + i_h) * K * K

    k += (bos * H + i_h) * K
    k_new += (bos * H + i_h) * K
    w1 += (bos * H + i_h) * K
    w2 += (bos * H + i_h) * K

    o_d = tl.arange(0, BK)
    m_d = o_d < K
    b_h = tl.zeros([BK, BK], dtype=tl.float32)
    for i_t_small in range(NT_small-1, -1, -1):
        o_k = (i_s * S + i_t_small * BT).to(tl.int64) + tl.arange(0, BT)
        m_k = o_k < T
        p_hc_suffix = hc_suffix + i_t_small * stride_h + o_d[:, None] * K + o_d[None, :]
        tl.store(p_hc_suffix, b_h.to(hc_suffix.dtype.element_ty), mask=m_d[:, None] & m_d[None, :])
        p_k = k + o_k[:, None] * (H*K) + o_d[None, :]
        b_k = tl.load(p_k, mask=m_k[:, None] & m_d[None, :], other=0.0)
        b_k = (b_k - tl.dot(b_k, tl.trans(b_h.to(b_k.dtype))))
        p_w1 = w1 + o_d[:, None] + o_k[None, :] * (H*K)
        p_w2 = w2 + o_k[:, None] * (H*K) + o_d[None, :]
        b_w1 = tl.load(p_w1, mask=m_d[:, None] & m_k[None, :], other=0.0)
        b_w2 = tl.load(p_w2, mask=m_k[:, None] & m_d[None, :], other=0.0)
        b_v_new = (b_w1 - tl.dot(b_h.to(b_w1.dtype), b_w1)).to(b_w2.dtype)
        b_h = tl.dot(b_v_new, b_w2, b_h)
        p_k_new = k_new + o_k[:, None] * (H*K) + o_d[None, :]
        tl.store(p_k_new, b_k.to(k_new.dtype.element_ty), mask=m_k[:, None] & m_d[None, :])

    p_hc_whole = hc_whole + o_d[:, None] * K + o_d[None, :]
    tl.store(p_hc_whole, b_h.to(hc_whole.dtype.element_ty), mask=m_d[:, None] & m_d[None, :])


def chunk_cumprod_householder_fwd_fn(
    k: torch.Tensor,
    w1: torch.Tensor,
    w2: torch.Tensor,
    S: int,  # split size, aka large chunk size
    BT: int,  # small chunk size
    cu_seqlens: torch.Tensor = None,
    chunk_indices: torch.LongTensor | None = None,
):
    B, T, H, K = k.shape

    if chunk_indices is None and cu_seqlens is not None:
        chunk_indices = prepare_chunk_indices(cu_seqlens, S)
    split_indices = chunk_indices
    chunk_offsets = prepare_chunk_offsets(cu_seqlens, BT) if cu_seqlens is not None else None
    split_offsets = prepare_chunk_offsets(cu_seqlens, S) if cu_seqlens is not None else None

    if cu_seqlens is None:
        N = B
        NS = N * triton.cdiv(T, S)
        NT = N * triton.cdiv(T, BT)
    else:
        N = len(cu_seqlens) - 1
        NS = split_offsets[-1]
        NT = chunk_offsets[-1]

    grid = (NS, H)
    hc_whole = torch.empty((NS, H, K, K), device=k.device, dtype=w1.dtype)
    k_new = torch.empty_like(k, dtype=k.dtype)
    hc_suffix = torch.empty((NT, H, K, K), device=k.device, dtype=w1.dtype)
    chunk_cumprod_householder_fwd_kernel[grid](
        k=k, k_new=k_new, w1=w1, w2=w2, hc_whole=hc_whole, hc_suffix=hc_suffix,
        cu_seqlens=cu_seqlens,
        split_indices=split_indices, chunk_offsets=chunk_offsets, split_offsets=split_offsets,
        BT=BT, K=K, H=H, BK=K,
        T=T, S=S,
        # SY (2025/07/08): I don't know why when K == 128 if I set num_warps=4 the result would be completely wrong
        num_warps=8 if K == 128 else 4,
        num_stages=3 if check_shared_mem('ampere') else 1,
    )
    return k_new, hc_suffix, hc_whole
