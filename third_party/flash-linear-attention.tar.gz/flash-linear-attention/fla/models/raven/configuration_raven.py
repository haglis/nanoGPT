# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors
#
# Portions of this file are adapted from Raven:
#   Copyright (c) 2023-2025 Arshia Afzal and Aviv Bick

import warnings

from transformers.configuration_utils import PretrainedConfig

from fla.models.hybrid import HybridAttentionConfig, _HybridAttentionConfigMixin


class RavenConfig(_HybridAttentionConfigMixin, PretrainedConfig):

    model_type = 'raven'
    keys_to_ignore_at_inference = ['past_key_values']

    def __init__(
        self,
        hidden_size: int = 2048,
        gate_logit_normalizer: int | None = 8,
        hidden_ratio: int | None = 4,
        intermediate_size: int | None = None,
        num_hidden_layers: int = 24,
        num_heads: int = 4,
        num_kv_heads: int | None = None,
        num_slots: int | None = 64,
        expand_k: float = 1,
        expand_v: float = 1,
        feature_map: str = 'swish',
        use_output_gate: bool = False,
        max_position_embeddings: int = 2048,
        hidden_act: str = "swish",
        decay_type: str = 'Mamba2',
        topk: int = 32,
        bias_rmm: bool = False,
        add_gumbel_noise: bool = True,
        router_score: str = 'sigmoid',
        router_type: str = 'lin',
        use_rope: bool = False,
        rope_theta: float = 10000.,
        elementwise_affine: bool | None = True,
        norm_eps: float = 1e-6,
        attn: HybridAttentionConfig = None,
        use_cache: bool = True,
        pad_token_id: int | None = None,
        bos_token_id: int = 1,
        eos_token_id: int = 2,
        initializer_range: float = 0.02,
        tie_word_embeddings: bool = False,
        fuse_norm: bool = True,
        fuse_swiglu: bool = True,
        fuse_cross_entropy: bool = True,
        fuse_linear_cross_entropy: bool = False,
        use_l2warp: bool = False,
        vocab_size: int = 32000,
        attnres_block_size: int | None = None,
        **kwargs,
    ):
        self.hidden_size = hidden_size
        self.gate_logit_normalizer = gate_logit_normalizer
        self.hidden_ratio = hidden_ratio
        self.intermediate_size = intermediate_size
        self.num_hidden_layers = num_hidden_layers
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.num_slots = num_slots
        self.expand_k = expand_k
        self.expand_v = expand_v
        self.feature_map = feature_map
        self.use_output_gate = use_output_gate
        self.max_position_embeddings = max_position_embeddings
        self.hidden_act = hidden_act
        self.decay_type = decay_type
        self.topk = topk
        self.bias_rmm = bias_rmm
        self.add_gumbel_noise = add_gumbel_noise
        self.router_score = router_score
        self.router_type = router_type
        self.use_rope = use_rope
        self.rope_theta = rope_theta
        self.elementwise_affine = elementwise_affine
        self.norm_eps = norm_eps
        self.attn = attn
        self.use_cache = use_cache
        self.initializer_range = initializer_range

        self.fuse_norm = fuse_norm
        self.fuse_swiglu = fuse_swiglu
        self.fuse_cross_entropy = fuse_cross_entropy
        self.fuse_linear_cross_entropy = fuse_linear_cross_entropy
        self.use_l2warp = use_l2warp
        self.vocab_size = vocab_size
        self.attnres_block_size = attnres_block_size

        if fuse_cross_entropy and fuse_linear_cross_entropy:
            raise ValueError(
                "`fuse_cross_entropy` and `fuse_linear_cross_entropy` cannot be True at the same time.",
            )
        if fuse_linear_cross_entropy:
            warnings.warn(
                "`fuse_linear_cross_entropy` is enabled, which can improves memory efficiency "
                "at the potential cost of reduced precision. "
                "If you observe issues like loss divergence, consider disabling this setting.",
            )

        if attnres_block_size is not None and attnres_block_size != 1:
            if attnres_block_size < 2 or attnres_block_size % 2 != 0:
                raise ValueError(
                    "`attnres_block_size` must be `None`, `1` (full mode), or an even integer (one block "
                    f"contains `attnres_block_size // 2` transformer layers); got {attnres_block_size}."
                )

        super().__init__(
            pad_token_id=pad_token_id,
            bos_token_id=bos_token_id,
            eos_token_id=eos_token_id,
            tie_word_embeddings=tie_word_embeddings,
            **kwargs,
        )
